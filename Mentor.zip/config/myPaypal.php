<?php

return [
    'clientId' => 'AQ9EoAXp8okP7HcD1PC7LSNYnCe2amuHj-Fog8VEEqD4IjuseTjiVlNoCOnzM7s29Ad5ITLbSo5eJ7nX',
    'secret' => 'EKExCau0sp7gIvggcdtDdsdzViIU6QcU6yWdXGsq21dhYstAn_eqQ7Kg8tPqqhwTfZQFStHcsIrxilUo'
];
