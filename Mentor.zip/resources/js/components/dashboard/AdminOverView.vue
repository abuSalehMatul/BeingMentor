<template>
    <div>
        <div class="row">

        </div>
    </div>
</template>

<script>
    import client from '@/client'
    export default {
        name: "admin-over-view",
        components: {

        },
        data() {
            return {
            }
        },
    }
</script>

