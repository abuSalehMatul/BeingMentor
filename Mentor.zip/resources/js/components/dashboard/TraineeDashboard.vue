<template>
    <div>
        <div class="row">

        </div>
    </div>
</template>

<script>
    import client from '@/client'
    export default {
        name: "trainee-dashboard",
        components: {

        },
        data() {
            return {
            }
        },
    }
</script>

