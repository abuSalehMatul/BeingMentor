<template>
    <div>
        <div class="row">

        </div>
    </div>
</template>

<script>
    import client from '@/client'
    export default {
        name: "mentor-trainee-bar-chart",
        components: {

        },
        data() {
            return {
            }
        },
    }
</script>

