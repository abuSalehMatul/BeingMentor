<template>
    <div>
        <div class="row">

        </div>
    </div>
</template>

<script>
    import client from '@/client'
    export default {
        name: "why-us",
        components: {

        },
        data() {
            return {
            }
        },
    }
</script>

