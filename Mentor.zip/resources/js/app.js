require('./bootstrap');
require('./include/component');
import Vue from 'vue'
const app = new Vue({
    el: '#app'
});