@extends('panels.backend')
@section('title', 'Contact Us')
@section('content')
    <forum user="{{$user}}"></forum>
@endsection
@section('route')
<script>

</script>
@endsection
