@extends('panels.backend')
@section('title', 'Contact Us')
@section('content')
    <success-story user="matulPermission"></success-story>
@endsection
@section('route')
<script>
  
</script>
@endsection
