@extends('panels.backend')
@section('title', 'Contact Us')
@section('content')
    <forum user="matulPermission"></forum>
@endsection
@section('route')
<script>

</script>
@endsection
