
<?php $__env->startSection('title', 'Contact Us'); ?>
<?php $__env->startSection('content'); ?>
    <forum user="matulPermission"></forum>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('route'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panels.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/panels/admin/forum.blade.php ENDPATH**/ ?>