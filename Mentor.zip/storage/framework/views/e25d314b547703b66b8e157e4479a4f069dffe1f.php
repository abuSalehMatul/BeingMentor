
<index :website ="<?php echo e($website); ?>"></index>
<?php /**PATH C:\xampp\htdocs\Mentor\resources\views/index.blade.php ENDPATH**/ ?>