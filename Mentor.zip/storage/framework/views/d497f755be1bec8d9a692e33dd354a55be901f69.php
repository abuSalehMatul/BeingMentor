<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Favicon-->
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('images/favicon.png')); ?>"/>

    <title><?php echo e(config('app.name', 'mentor')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/adminator.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body class="app">
<div>
    <!-- @Page  Loader -->
    <!-- =================================================== -->
    <div id='loader'>
        <div class="spinner"></div>
    </div>

    <script>
        window.addEventListener('load', () => {
            const loader = document.getElementById('loader');
            setTimeout(() => {
                loader.classList.add('fadeOut');
            }, 300);
        });
    </script>
    <!-- @App  Content -->
    <!-- =================================================== -->
    <div>
        <!-- #Left Sidebar ==================== -->
        <?php echo $__env->make('panels.include.leftbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- #Main ============================ -->
        <div class="page-container" id="app">
            <!-- ### $Topbar ### -->
            <?php echo $__env->make('panels.include.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- ### $App Screen Content ### -->
            <main class='main-content bgc-grey-100'>
                <div id='mainContent'>
                    <div class="full-container">
                        <?php echo $__env->yieldContent('container'); ?>
                        <!-- ### $App Screen Footer ### -->
                        <footer class="bdT ta-c p-30 lh-0 fsz-sm c-grey-600">
                            <span>Copyright © <?php echo e(now()->year); ?>, All rights reserved.</span>
                        </footer>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Scripts -->
    <?php echo $__env->yieldContent('route'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/adminator.js')); ?>" defer></script>
    <?php echo $__env->yieldPushContent('js'); ?>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Mentor\resources\views/panels/adminator.blade.php ENDPATH**/ ?>