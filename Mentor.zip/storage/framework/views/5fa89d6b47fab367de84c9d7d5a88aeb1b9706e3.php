<div class="package-div">
    <div class="et_pb_module dsm_dual_heading dsm_dual_heading_4  et_pb_text_align_center et_pb_bg_layout_light">
        <div class="et_pb_module_inner">
            <h1 class="dsm-dual-heading-main et_pb_module_header"><span class="dsm-dual-heading-before">Package</span><span class="dsm-dual-heading-middle"> LIST</span></h1>
        </div>
    </div>
    <div class="row">
        <?php
        $packages = DB::table('packages')->get();
        $i =0;
        $color =['#38c172', '#1FB6EA', '#2D82D0'];
        ?>
        <div class="packageList">
            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="package-box col-md-3" style="background: <?php echo e($color[$i]); ?>; margin-left:55px">
                <?php
                $i++;
                ?>
                <div>
                    <h5 class="package-name"> <?php echo e($package->name); ?> </h5>
                    <img src="<?php echo e($package->icon); ?>" class="package-icon">
                </div>
                <div class="package-title">
                    <?php echo e($package->short_title); ?>

                </div>
                <div class="package-description">
                    <?php echo e($package->description); ?>

                </div>
                <div class="package-info">
                    <?php if($package->duration): ?>
                    <h6>Duration: <?php echo e($package->duration); ?> Months</h6>
                    <?php endif; ?>
                    <?php if($package->price): ?>
                    <h6>Price: $<?php echo e($package->price); ?></h6>
                    <?php else: ?> 
                    <h6>Price: $0 (Free)</h6>
                    <?php endif; ?>
                    <?php if($package->video_calling): ?>
                    <h6>Video Calling: <?php echo e($package->video_calling); ?></h6>
                    <?php endif; ?>
                    <?php if($package->chatting): ?>
                    <h6>Chatting: <?php echo e($package->chatting); ?></h6>
                    <?php endif; ?>
                    <?php if($package->questions): ?>
                    <h6>Questions: <?php echo e($package->questions); ?></h6>
                    <?php endif; ?>
                </div>
                <div>
                    <form method="post" action="<?php echo e(route('submit-package')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="package_id" value="<?php echo e($package->id); ?>">
                        <input type="submit" value="purchase" class="btn btn-lg package-btn">
                    </form>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Mentor\resources\views/packages.blade.php ENDPATH**/ ?>