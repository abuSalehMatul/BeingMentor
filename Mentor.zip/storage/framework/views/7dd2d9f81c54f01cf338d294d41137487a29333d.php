<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
    <admin-dashboard></admin-dashboard>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('mentor')): ?>
    <mentor-dashboard></mentor-dashboard>
    <?php endif; ?>
    <?php if(auth()->check() && auth()->user()->hasRole('trainee')): ?>
    <trainee-dashboard></trainee-dashboard>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('route'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panels.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/panels/home.blade.php ENDPATH**/ ?>