<?php $__env->startSection('container'); ?>
<article id="post-9" class="post-9 page type-page status-publish hentry">
    <div class="entry-content">
        <div class="et-l et-l--post">
            <div class="et_builder_inner_content et_pb_gutters3">
                <mentor user_id="<?php echo e($user_id); ?>"></mentor>
            </div>
        </div>
    </div>
</article>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('route'); ?>
<script>
    window.getMentorRoute = "<?php echo e(route('api.get.mentor', $user_id)); ?>";
    window.chatInitializerRoute ="<?php echo e(route('chat.initializer')); ?>";
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/mentor.blade.php ENDPATH**/ ?>