<?php $__env->startSection('container'); ?>
<article id="post-9" class="post-9 page type-page status-publish hentry">
    <div class="entry-content">
        <div class="et-l et-l--post">
            <div class="col-md-12 col-sm-12 card">
                <div class="card-body">
                <img src="<?php echo e(asset('images/aboutus.jpg')); ?>" class="d-block -m-1 img-fluid img-thumbnail" style="min-width:100%;height: 40%">
                </div>
                <div class="card-body">
                    <?php
                         print_r($website->about_us);
                    ?>
                </div>

            </div>
        </div>
    </div>
</article>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/aboutUs.blade.php ENDPATH**/ ?>