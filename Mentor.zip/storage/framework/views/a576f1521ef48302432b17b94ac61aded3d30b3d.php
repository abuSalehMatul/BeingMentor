
<?php $__env->startSection('title', 'Find Mentor'); ?>
<?php $__env->startSection('content'); ?>
    <mentor user_id="<?php echo e($user_id); ?>"></mentor>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('route'); ?>
<script>
    window.getMentorRoute = "<?php echo e(route('api.get.mentor', $user_id)); ?>";
    window.chatInitializerRoute ="<?php echo e(route('chat.initializer')); ?>";
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panels.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/panels/findMentor.blade.php ENDPATH**/ ?>