
<?php $__env->startSection('title', 'Contact Us'); ?>
<?php $__env->startSection('content'); ?>
<div class="bgc-white bd bdrs-3 p-20 mB-20 mT-15">
    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form method="post" action="<?php echo e(route('save.package')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <input type="hidden" value="<?php echo e($package->id); ?>" name="package_id">
            <div class="form-group col-md-6">
                <label> Name of the package </label>
                <input type="text" value="<?php echo e($package->name); ?>" class="form-control" name="name" required>
            </div>
            <div class="form-group col-md-12">
                <label> Short title </label>
                <input type="text" value="<?php echo e($package->short_title); ?>" class="form-control" required name="short_title">
            </div>
            <div class="form-group col-md-6 col-sm-12">
                <label> Duration </label>
                <input type="number" value="<?php echo e($package->duration); ?>" class="form-control" required name="duration">
            </div>
            <div class="form-group col-md-5 col-sm-12">
                <label> Price (in dollar) </label>
                <input type="number" value="<?php echo e($package->price); ?>" class="form-control" required name="price">
            </div>
            <div class="form-group col-md-6 col-sm-12">
                <label> Number of video call ? </label>
                <input type="number" value="<?php echo e($package->video_calling); ?>" class="form-control" name="video_calling">
            </div>
            <div class="form-group col-md-6 col-sm-12">
                <label> Number of Chat ? </label>
                <input type="number" value="<?php echo e($package->chatting); ?>" class="form-control" name="chatting">
            </div>
            <div class="form-group col-md-6 col-sm-12">
                <label> Number of Question can ask? </label>
                <input type="number" value="<?php echo e($package->questions); ?>" class="form-control" name="questions">
            </div>
             <div class="form-group col-md-12 col-sm-12">
                <label> Icon of the package </label>
                <input type="file"  class="form-control" name="icon">
                <img src="<?php echo e($package->icon); ?>" class="img-fluid img-thumbnail rounded">
            </div>
            <div class="form-group col-md-12 col-sm-12">
                <label> Description </label>
                <textarea class="form-control" name="description" value="<?php echo e($package->description); ?>">
                <?php echo e($package->description); ?>

                 </textarea>
            </div>
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-lg btn-success" value="Save this Package">
        </div>

    </form>
    <hr>
    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('route'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panels.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/panels/admin/package.blade.php ENDPATH**/ ?>