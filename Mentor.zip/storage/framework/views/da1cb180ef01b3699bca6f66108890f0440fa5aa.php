

<html>
<head>
  <meta charset="utf-8">
  <title>The HTML5 Herald</title>
  <meta name="description" content="The HTML5 Herald">
  <meta name="author" content="SitePoint">
  
</head>

<body>
<script> 
  var vidyoConnctorOb;
  function onVidyoClientLoaded(status){
     // console.log(status);
      VC.CreateVidyoConnector({
          viewId: "render",
          viewStyle: "VIDYO_CONNECTORVIEWSTYLE_Default",
          remoteParticipants: 10,
          logFileFilter: "error",
          logFileName: "",
          userData: ""
      }).then(function(vc){
          console.log(vc);
          vidyoConnctorOb = vc;
      }).catch(function(error){
          console.log(error);
      });

  }

  function joinCall(){
      vidyoConnctorOb.Connect({
          host: "prod.vidyo.io",
          token: "cHJvdmlzaW9uAHVzZXIxQDUwMzY1Ny52aWR5by5pbwA2Mzc1NTY5NTY0NgAAYWIxZjlmMDE0M2YzZjNmMmFiYzE3ZjNhM2UzZWEzNjBkZTFhNmQyMjk1MmI1Mjc1MTI2YjViNDQ4M2ViNzc0NmFiZTlmNzNmOTliYWI4ZDNlOThkMzAwYWZkOGE3MmYz",
          displayName: "matul",
          resourceId: "demoroom",
          onSuccess: function(){

          },
          onFailure: function(reason){

          },
          onDisconnected: function(reason){

          }
      })
  }
  </script>
<script src="https://static.vidyo.io/latest/javascript/VidyoClient/VidyoClient.js?onload=onVidyoClientLoaded"></script>
video
  <div id="render">
  </div>
  <button onclick="joinCall()"> Join Call </button>
</body>
</html><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/video.blade.php ENDPATH**/ ?>