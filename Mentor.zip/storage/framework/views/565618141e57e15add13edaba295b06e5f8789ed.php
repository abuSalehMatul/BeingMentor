<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Favicon-->
    <link rel="shortcut icon" type="image/png" href="<?php echo e($website->logo); ?>" />
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <title><?php echo e(config('app.name', 'Mentor')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Styles -->

    
    <link href="<?php echo e(asset('customStyle/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('customStyle/myStyle.css')); ?>" rel="stylesheet">
    <link rel="stylesheet"
          href=
"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <?php echo $__env->yieldContent('css'); ?>

</head>

<body class="app" id="">
    <div>
        <!-- @Page  Loader -->
        <!-- =================================================== -->
        <div id='loader'>
            <div class="spinner"></div>
        </div>

        <script>
            window.addEventListener('load', () => {
            const loader = document.getElementById('loader');
            setTimeout(() => {
                loader.classList.add('fadeOut');
            }, 300);
        });
        </script>
        <!-- @App  Content -->
        <!-- =================================================== -->
        <div
            class="et-db et_fixed_nav et_header_style_left et_primary_nav_dropdown_animation_fade et_smooth_scroll et_transparent_nav">
            <!-- #Main ============================ -->
            <div class="page-container et-boc" id="app">
                <!-- ### $Topbar ### -->
                <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- ### $App Screen Content ### -->
                <main class='main-content bgc-grey-100'>
                    <div id='mainContent'>
                        <div class="full-container">
                            <?php echo $__env->yieldContent('container'); ?>
                            <!-- ### $App Screen Footer ### -->
                            
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <!-- Scripts -->
        <?php echo $__env->yieldContent('route'); ?>
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <?php echo $__env->yieldPushContent('js'); ?>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Mentor\resources\views/layouts/app.blade.php ENDPATH**/ ?>