
<?php $__env->startSection('title', 'Tag'); ?>
<?php $__env->startSection('content'); ?>
   <admin-tag></admin-tag>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('route'); ?>
<script>
   window.getTagRoute = "<?php echo e(route('api.admin.get.tag')); ?>";
   window.saveTagRoute = "<?php echo e(route('api.admin.save.tag')); ?>";
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panels.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/panels/admin/tag.blade.php ENDPATH**/ ?>