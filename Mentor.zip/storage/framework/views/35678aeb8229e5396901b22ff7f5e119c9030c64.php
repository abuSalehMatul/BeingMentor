<?php $__env->startSection('title', 'Chat Room'); ?>
<?php $__env->startSection('content'); ?>
    <chat-room :room_id="<?php echo e($roomId); ?>" :own_id="<?php echo e($ownId); ?>"></chat-room>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('route'); ?>
<script>
    window.getChatRoute = "<?php echo e(route('api.panel.chatroom', $roomId)); ?>";
    window.setTicketRoute = "<?php echo e(route('api.panel.chatromm.ticket', $roomId)); ?>";
    window.sendChatRoute ="<?php echo e(route('api.panel.send.message', $roomId)); ?>";
    window.postTicketRoute ="<?php echo e(route('api.panel.solve.ticket')); ?>";
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panels.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/panels/chatroom.blade.php ENDPATH**/ ?>