<?php $__env->startSection('title', 'Website'); ?>
<?php $__env->startSection('content'); ?>
<div class="bgc-white bd bdrs-3 p-20 mB-20 mT-15">
    <div class="bg-info col-md-12 text-danger p-10 m-20 text-center"> Web Site Information </div>
    <form method="POST" action="<?php echo e(route('panels.admin.website.update')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row m-10 p-10">
            <label>Website Email</label>
            <input type="email" class="form-control" value="<?php echo e($website->email); ?>" placeholder="<?php echo e($website->email); ?>" name="email">
            <label>Mobile</label>
            <input type="text" class="form-control" value="<?php echo e($website->mobile); ?>" placeholder="<?php echo e($website->mobile); ?>" name="mobile">
            <label>Phone</label>
            <input type="text" class="form-control" value="<?php echo e($website->mobile1); ?>" placeholder="<?php echo e($website->mobile1); ?>" name="mobile1">
            <label>Footer Quote</label>
            <input type="text" class="form-control" value="<?php echo e($website->footer_quote); ?>"  name="footer_quote">
            <label>Address</label>
            <input type="text" class="form-control" value="<?php echo e($website->address); ?>" placeholder="<?php echo e($website->address); ?>" name="address">

            <label>Quote Title 1</label>
            <input type="text" class="form-control" value="<?php echo e($website->quote_title1); ?>" placeholder="<?php echo e($website->quote_title1); ?>" name="quote_title1">

            <label>Quote Title 2</label>
            <input type="text" class="form-control" value="<?php echo e($website->quote_title1); ?>" placeholder="<?php echo e($website->quote_title1); ?>" name="quote_title2">

            <label>How it works title 1</label>
            <input type="text" class="form-control" value="<?php echo e($website->how_it_work_title1); ?>" placeholder="<?php echo e($website->how_it_work_title1); ?>" name="how_it_work_title1">

            <label>How it works title 2</label>
            <input type="text" class="form-control" value="<?php echo e($website->how_it_work_title2); ?>" placeholder="<?php echo e($website->how_it_work_title2); ?>" name="how_it_work_title2">

            <label>How it works title 3</label>
            <input type="text" class="form-control" value="<?php echo e($website->how_it_work_title3); ?>" placeholder="<?php echo e($website->how_it_work_title3); ?>" name="how_it_work_title3">


            <h3 class="col-md-12 ">Website Logo</h3>
            <img src="<?php echo e($website->logo); ?>" class="img-fluid img-thumbnail rounded mx-auto d-block col-md-5 col-sm-12" >
            <label class="col-md-12">Add A new Logo</label>
            <input type="file" class="form-control" name="logo">

            <h3 class="col-md-12 ">How it works image 1</h3>
            <img src="<?php echo e($website->how_it_work_image_one); ?>" class="img-fluid img-thumbnail rounded mx-auto d-block col-md-5 col-sm-12" >
            <label class="col-md-12">Add A new Image</label>
            <input type="file" class="form-control" name="how_it_work_image_one">

            <h3 class="col-md-12 ">How it works image 2</h3>
            <img src="<?php echo e($website->how_it_work_image_two); ?>" class="img-fluid img-thumbnail rounded mx-auto d-block col-md-5 col-sm-12" >
            <label class="col-md-12">Add A new Image</label>
            <input type="file" class="form-control" name="how_it_work_image_two">

            <h3 class="col-md-12 ">How it works image 3</h3>
            <img src="<?php echo e($website->how_it_work_image_three); ?>" class="img-fluid img-thumbnail rounded mx-auto d-block col-md-5 col-sm-12" >
            <label class="col-md-12">Add A new Image</label>
            <input type="file" class="form-control" name="how_it_work_image_three">
        </div>
        <h4>
            Index description
        </h4>
        <input class="form-control" value="<?php echo e($website->index_description); ?>" name="index_description">

        <div id="sample">
            <h4>
                About Us
            </h4>
            <textarea style="width: 100%; height: 100px;" value="<?php echo e($website->about_us); ?>" name="about_us">
                <?php
                    print_r($website->about_us)
                ?>
            </textarea>

            <h4>
                Quote description 2
            </h4>
            <textarea style="width: 100%; height: 100px;" value="<?php echo e($website->quote_description2); ?>" name="quote_description2">
                <?php
                    print_r($website->quote_description2)
                ?>
            </textarea>

            <h4>
                Quote description 1
            </h4>
            <textarea style="width: 100%; height: 100px;" value="<?php echo e($website->quote_description1); ?>" name="quote_description1">
                <?php
                    print_r($website->quote_description1)
                ?>
            </textarea>
            <br />
            <h4>
                Term and policy
            </h4>
                <textarea  style="width: 100%; height: 100px;" name="term_policy" value="<?php echo e($website->term_policy); ?>">
                <?php
                    print_r($website->term_policy)
                ?>
            </textarea>
            <br />
            <h4>
                How it Works
            </h4>
            <textarea  style="width: 100%; height: 100px;" name="how_it_works">
                <?php
                    print_r($website->how_it_works)
                ?>
            </textarea>

            <br />
            <h4>
                How it work description 1
            </h4>
            <textarea  style="width: 100%; height: 100px;" name="how_it_work_description1">
                <?php
                    print_r($website->how_it_work_description1)
                ?>
            </textarea>

            <br />
            <h4>
                How it work description 2
            </h4>
            <textarea  style="width: 100%; height: 100px;" name="how_it_work_description2">
                <?php
                    print_r($website->how_it_work_description2)
                ?>
            </textarea>


            <br />
            <h4>
                How it work description 3
            </h4>
            <textarea  style="width: 100%; height: 100px;" name="how_it_work_description3">
                <?php
                    print_r($website->how_it_work_description3)
                ?>
            </textarea>

            <br />
            <h4>
                Why us ?
            </h4>
            <textarea  style="width: 100%; height: 100px;" name="why_us_description">
                <?php
                    print_r($website->why_us_description)
                ?>
            </textarea>
        </div>
        <hr>
        <hr>
        <div class="form-group">
            <input type="submit" class="btn btn-success col-md-12 p-10 m-15" value="Update">
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('route'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('panels.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/panels/admin/website.blade.php ENDPATH**/ ?>