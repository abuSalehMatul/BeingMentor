
<footer-section :website="<?php echo e($website); ?>"> </footer-section>

<?php /**PATH C:\xampp\htdocs\Mentor\resources\views/footer.blade.php ENDPATH**/ ?>