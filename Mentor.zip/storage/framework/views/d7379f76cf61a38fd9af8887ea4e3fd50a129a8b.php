
<?php $__env->startSection('container'); ?>
<article id="post-9" class="post-9 page type-page status-publish hentry">
    <div class="entry-content">
        <div class="et-l et-l--post">
            <div class="et_builder_inner_content et_pb_gutters3">
            <?php
                $message = Session::get('package-message');
            ?>
            <?php if($message): ?>
                <div class="card-title">
                      <h3 class="text-center text-danger"> <?php echo e($message); ?> </h3>
                 </div>
            <?php endif; ?>
                <?php echo $__env->make('packages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</article>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/onlyPackage.blade.php ENDPATH**/ ?>