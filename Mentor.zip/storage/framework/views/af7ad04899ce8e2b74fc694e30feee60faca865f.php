<mentor-info user_id="website"></mentor-info>
<?php $__env->startSection('route'); ?>
<script>
    window.getMentorRoute = "<?php echo e(route('api.get.mentor', 'website')); ?>";
    window.chatInitializerRoute ="<?php echo e(route('chat.initializer')); ?>";
</script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/mentorInfo.blade.php ENDPATH**/ ?>