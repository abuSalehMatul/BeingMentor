
<how-we-work :website="<?php echo e($website); ?>"></how-we-work>
<?php /**PATH C:\xampp\htdocs\Mentor\resources\views/howWeWork.blade.php ENDPATH**/ ?>