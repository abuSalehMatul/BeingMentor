<?php $__env->startSection('container'); ?>
    <div class="container-fluid">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        <?php if(auth()->guard()->check()): ?>
            window.authId = "<?php echo e(auth()->id()); ?>";
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('panels.adminator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/panels/backend.blade.php ENDPATH**/ ?>