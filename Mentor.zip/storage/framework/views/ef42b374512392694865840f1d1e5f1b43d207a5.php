<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
    <profile></profile>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('route'); ?>
<script>
    window.getProfileRoute = "<?php echo e(route('api.panel.profile.index')); ?>";
    window.updateProfileRoute = "<?php echo e(route('api.panel.profile.update')); ?>";
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panels.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/panels/profile.blade.php ENDPATH**/ ?>