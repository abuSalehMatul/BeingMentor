
<?php $__env->startSection('title', 'My Messages'); ?>
<?php $__env->startSection('content'); ?>
    <message :user_id="<?php echo e($userId); ?>"></message>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('route'); ?>
<script>
    window.getMyMessageRoute = "<?php echo e(route('api.panel.my.message', $userId)); ?>";
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panels.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Mentor\resources\views/panels/message.blade.php ENDPATH**/ ?>